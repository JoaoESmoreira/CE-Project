#!/bin/sh

pypy3 solve.py
pypy3 solve2.py
pypy3 aco.py
